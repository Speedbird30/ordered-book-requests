/*
Name: Sumit Subhash Jadhav
U89612131.

*/
#ifndef READLINE_H
#define READLINE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int read_line(char str[], int n);

#endif // READLINE_H
