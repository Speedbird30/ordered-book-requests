/*
Name: Sumit Subhash Jadhav
U89612131.

*/
#include "book.h"
#include "readline.h"

struct book *add_to_end(struct book *list)
/*
Ask the user to enter a book�s title, author�s first name, author�s last name, and classroom and
checks whether the book has already existed by title, author�s name, and classroom.
*/
{
    struct book *cur, *prev, *new_book;

    new_book = malloc(sizeof(struct book));
    if(new_book == NULL)
    {
        printf("Error: Malloc");
        return list;
    }

    printf("Enter title: ");
    read_line(new_book->title, TITLE_LEN);
    printf("Enter author's first name: ");
    read_line(new_book->first, NAME_LEN);
    printf("Enter author's last name: ");
    read_line(new_book->last, NAME_LEN);
    printf("Enter classroom: ");
    read_line(new_book->classroom, ROOM_LEN);

    for(cur = list, prev = NULL; cur != NULL && strcmp(new_book->last, cur->last) > 0; prev = cur, cur = cur->next);
    if(cur!= NULL && strcmp(new_book->last, cur->last) == 0)
    {
        for(cur = list, prev = NULL; cur != NULL && strcmp(new_book->last, cur->last) == 0 && strcmp(new_book->first, cur->first) > 0 || strcmp(new_book->last, cur->last) > 0; prev = cur, cur = cur->next);
    }

    if(cur != NULL && strcmp(cur->title,new_book->title)==0 && strcmp(cur->first,new_book->first)==0 && strcmp(cur->last,new_book->last)==0 && strcmp(cur->classroom,new_book->classroom)==0)
    {
        printf("Book already added.");
        free(new_book);
        return list;
    }

    printf("Enter price: ");
    scanf("%lf", &new_book->price);

    new_book->next = cur;
    if(prev == NULL)
    {
        return new_book;
    }

    else
    {
        prev->next = new_book;
        return list;
    }
}

void print_list(struct book *list) // print the title, author, price, and classroom of all books in the list
{
    while (list != NULL)
    {
        printf("Title: %s\n", list->title);
        printf("Author: %s %s\n", list->first, list->last);
        printf("Classroom: %s", list->classroom);
        printf("Price: $%.2f", list->price);
        list = list -> next;
    }
}
void clear_list(struct book *list)   //memory allocated for the linked list is released
{
  struct book *p;
  while(list != NULL)
  {
	 p = list;
     list = list->next;
     if( p!= NULL)
           free(p);
  }
}
